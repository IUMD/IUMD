!*******************************************************************************
!
!    MD 6.3.1
! ---------------------------------------------------------------------
!    Copyright 2013, The Trustees of Indiana University
!    Authors:           Don Berry
!    Last modified by:  Don Berry, 2013-Mar-17
! ---------------------------------------------------------------------
!
! Timers and counters for doing performance analysis
!
!*******************************************************************************


      real(dbl)   t_md,        ts_md,       &
                  t_newton,    ts_newton,   &
                  t_accel,     ts_accel,    &
                  t_calc_a,    ts_calc_a,   &
                  t_vtot,      ts_vtot,     &
                  t_calc_v,    ts_calc_v,   &
                  t_g,         ts_g,        &
                  t_pressure,  ts_pressure, &
                  t_calc_vir,  ts_calc_vir, &
                  t_strain,    ts_strain,   &
                  t_calc_nnm,  ts_calc_nnm, &
                  t_calc_nn,   ts_calc_nn,  &
                  t_calc_scm,  ts_calc_scm, &
                  t_calc_sc,   ts_calc_sc,  &
                  t_bld_nlt,   ts_bld_nlt,  &
                  t_bld_nlb,   ts_bld_nlb

      common /timers/    &
         t_md,        ts_md,           &
         t_newton,    ts_newton,       &
         t_accel,     ts_accel,        &
         t_calc_a,    ts_calc_a,       &
         t_vtot,      ts_vtot,         &
         t_calc_v,    ts_calc_v,       &
         t_g,         ts_g,            &
         t_pressure,  ts_pressure,     &
         t_calc_vir,  ts_calc_vir,     &
         t_strain,    ts_strain,       &
         t_calc_nnm,  ts_calc_nnm,     &
         t_calc_nn,   ts_calc_nn,      &
         t_calc_scm,  ts_calc_scm,     &
         t_calc_sc,   ts_calc_sc,      &
         t_bld_nlt,   ts_bld_nlt,      &
         t_bld_nlb,   ts_bld_nlb

      integer  n_md,        &
               n_newton,    &
               n_accel,     &
               n_calc_a,    &
               n_vtot,      &
               n_calc_v,    &
               n_g,         &
               n_pressure,  &
               n_calc_vir,  &
               n_strain,    &
               n_calc_nnm,  &
               n_calc_nn,   &
               n_calc_scm,  &
               n_calc_sc,   &
               n_bld_nlt,   &
               n_bld_nlb

      common /counters/  &
         n_md,           &
         n_newton,       &
         n_accel,        &
         n_calc_a,       &
         n_vtot,         &
         n_calc_v,       &
         n_g,            &
         n_pressure,     &
         n_calc_vir,     &
         n_strain,       &
         n_calc_nnm,     &
         n_calc_nn,      &
         n_calc_scm,     &
         n_calc_sc,      &
         n_bld_nlt,      &
         n_bld_nlb
